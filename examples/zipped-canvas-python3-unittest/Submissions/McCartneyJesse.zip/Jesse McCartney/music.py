# This is an example of the file that would be provided to the student in this case
# Note that this file should not be part of the grader config supportFiles since it is not required for grading
#
#
# FIRST VERSION OF SUBMISSION: NOTE THAT THIS WAS THE FIRST VERSION OF THE SUBMITTED FILE, AND SHOULD NOT BE GRADED
#
# @author your name/id here

import song_title_helper

def what_we_could_have_been_together():
    print(song_title_helper.get_song_name())
    return 'an awkward music video couple'

def what_we_could_have_lived_together():
    return '2004 nostalgia'

def who_is_going_to_dance_with_me():
    return 'you and your beautiful soul'

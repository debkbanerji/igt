This is an example of a file a student might have submitted with the same name as a provided file.
It should be overwritten by the provided file while running tests.
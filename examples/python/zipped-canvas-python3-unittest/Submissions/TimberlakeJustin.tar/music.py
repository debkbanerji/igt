# This is an example of the file that would be provided to the student in this case
# Note that this file should not be part of the grader config supportFiles since it is not required for grading
#
# @author Justin Timberlake

def what_we_could_have_been_together():
    while True:
        pass

def what_we_could_have_lived_together():
    while True:
        pass

def who_is_going_to_dance_with_me():
    while True:
        pass

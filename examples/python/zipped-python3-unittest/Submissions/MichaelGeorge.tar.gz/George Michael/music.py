# This is an example of the file that would be provided to the student in this case
# Note that this file should not be part of the grader config supportFiles since it is not required for grading
#
# @author George Michael

def what_we_could_have_been_together():
    return 'so good'

def what_we_could_have_lived_together():
    return 'this dance'

def who_is_going_to_dance_with_me():
    raise RuntimeError
